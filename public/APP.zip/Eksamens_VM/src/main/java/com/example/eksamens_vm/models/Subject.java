package com.example.eksamens_vm.models;

public class Subject {
}
