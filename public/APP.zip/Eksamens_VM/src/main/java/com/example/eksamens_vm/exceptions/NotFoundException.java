package com.example.eksamens_vm.exceptions;

public class NotFoundException extends Exception {
    public NotFoundException(String message){
        super(message);
    }
}
