package com.example.eksamens_vm.enums;

public enum UserRole {
    STUDENT,
    TEACHER
}
