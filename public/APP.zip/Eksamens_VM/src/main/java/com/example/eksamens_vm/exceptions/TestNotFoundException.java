package com.example.eksamens_vm.exceptions;

public class TestNotFoundException extends Exception {
    public TestNotFoundException(String message) {
        super(message);
    }
}
