package com.example.eksamens_vm.exceptions;

public class InputFieldEmptyException extends Exception {

    public InputFieldEmptyException(String message) {
        super(message);
    }
}
