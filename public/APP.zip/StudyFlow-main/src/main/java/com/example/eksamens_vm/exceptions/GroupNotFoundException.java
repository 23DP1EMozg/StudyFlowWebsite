package com.example.eksamens_vm.exceptions;

public class GroupNotFoundException extends Exception {
    public GroupNotFoundException(String message) {
        super(message);
    }
}
