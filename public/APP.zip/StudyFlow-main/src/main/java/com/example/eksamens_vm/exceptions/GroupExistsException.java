package com.example.eksamens_vm.exceptions;

public class GroupExistsException extends Exception {
    public GroupExistsException(String message) {
        super(message);
    }
}
